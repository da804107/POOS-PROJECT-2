import '../styles/IndexCardUI.css';
import React, { useState } from 'react';

function IndexCardUI() {
    return(
        <div id="sampleDiv">
            <span id="sampleText">Allow users to view a study set as index cards, one term at a time to study with.</span><br />
        </div>
    );
}

export default IndexCardUI;