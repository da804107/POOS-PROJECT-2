import '../styles/PageTitle.css';

function PageTitle() {
    return (
        <h1 id="title">STUDY BUDDY</h1>
    );
};

export default PageTitle;
