import '../styles/EditStudySetUI.css';
import React, { useState } from 'react';

function EditStudySetUI() {
    return(
        <div id="sampleDiv">
            <span id="sampleText">Allow users to view a specific study set, edit it if necessary. and from here click to view it as a index card.</span><br />
        </div>
    );
}

export default EditStudySetUI;